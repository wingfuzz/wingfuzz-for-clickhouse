SELECT /*/**/*/ 1;
SELECT /*a/*b*/c*/ 1;
SELECT /*ab/*cd*/ef*/ 1;
