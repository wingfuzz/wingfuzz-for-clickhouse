select * from remote('127.1', system.one) settings max_distributed_connections=0;
