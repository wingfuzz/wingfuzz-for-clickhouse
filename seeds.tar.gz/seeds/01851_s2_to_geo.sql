-- Tags: no-fasttest
-- Tag no-fasttest: needs s2

select s2ToGeo(4573520603753570041);
select s2ToGeo(4573517609713934091);
