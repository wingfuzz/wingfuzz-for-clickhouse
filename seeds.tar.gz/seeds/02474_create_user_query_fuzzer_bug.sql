EXPLAIN AST ALTER user WITH a; -- { clientError SYNTAX_ERROR }
