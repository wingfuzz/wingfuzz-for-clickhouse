SELECT CONCAT('Hello', ', ', 'world!');
