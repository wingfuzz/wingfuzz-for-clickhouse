-- Tags: no-ordinary-database, no-parallel

create database if not exists test_00604;
show create database test_00604;
drop database test_00604;
