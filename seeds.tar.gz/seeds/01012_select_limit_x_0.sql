SELECT count() FROM system.numbers LIMIT 1, 0;
