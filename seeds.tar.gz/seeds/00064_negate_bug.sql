SELECT -toUInt32(1) AS x, toTypeName(x) AS t
