CREATE TABLE log (A String) ENGINE= FileLog('/tmp/aaa.csv', 'CSV'); -- {serverError 36 }
CREATE TABLE log (A String) ENGINE= FileLog('/tmp/aaa.csv', 'CSV'); -- {serverError 36 }
CREATE TABLE log (A String) ENGINE= FileLog('/tmp/aaa.csv', 'CSV'); -- {serverError 36 }
