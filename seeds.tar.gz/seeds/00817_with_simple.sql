WITH number AS k SELECT k FROM system.numbers LIMIT 10;
