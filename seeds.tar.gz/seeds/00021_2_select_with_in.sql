select sum(Sign) from test.visits where CounterID in (942285, 577322);
