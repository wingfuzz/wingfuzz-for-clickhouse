SELECT toString(arrayCumSumNonNegative(x->0, [1, 2]));
