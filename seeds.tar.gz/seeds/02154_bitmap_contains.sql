select bitmapContains(bitmapBuild([9]), 964291337)
