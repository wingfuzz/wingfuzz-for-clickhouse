SELECT dateDiff('h', toDateTime('2018-01-01 22:00:00'), toDateTime('2018-01-02 23:00:00'));
SELECT  toDateTime('2018-01-01 22:00:00') + INTERVAL 4 h
