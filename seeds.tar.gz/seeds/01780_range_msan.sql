SELECT range(toUInt256(1), 1); -- { serverError 44 }
