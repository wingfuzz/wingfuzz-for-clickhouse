SELECT intDiv(10, 4);
SELECT intDiv(10., 4);
SELECT intDiv(10, 4.);
SELECT intDiv(10., 4.);
SELECT intDiv(1, 0.3);
SELECT intDiv(1.0, 0.3);
