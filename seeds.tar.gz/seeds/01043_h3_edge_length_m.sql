-- Tags: no-fasttest

SELECT h3EdgeLengthM(1);
SELECT h3EdgeLengthM(4);
