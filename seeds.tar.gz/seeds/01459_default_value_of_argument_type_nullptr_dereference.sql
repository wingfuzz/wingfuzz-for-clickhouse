SELECT defaultValueOfTypeName(FQDN()); -- { serverError 44 }
