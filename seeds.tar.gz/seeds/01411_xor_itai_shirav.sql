SELECT xor(1, 0);
