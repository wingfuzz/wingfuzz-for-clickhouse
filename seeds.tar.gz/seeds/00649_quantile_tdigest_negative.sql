SELECT quantileTDigest(0.5)(arrayJoin([-1, -2, -3]));
