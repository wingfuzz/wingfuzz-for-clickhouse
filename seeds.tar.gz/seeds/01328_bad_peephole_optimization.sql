select max(a + b) from (SELECT 1 AS a, 2 AS b);
