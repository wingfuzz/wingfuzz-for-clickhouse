SELECT CAST([] AS Array(Array(String)));
SELECT CAST([] AS Array(Array(Array(String))));
