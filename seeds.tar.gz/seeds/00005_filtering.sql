SELECT count() FROM test.hits WHERE AdvEngineID != 0

