SELECT 1 x FROM system.one;
SELECT 1 + (2 AS x) y FROM system.one;
