WITH dummy AS myName SELECT myName FROM system.one;
WITH dummy AS myName SELECT myName + 1 FROM system.one;
