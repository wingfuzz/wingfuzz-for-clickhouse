SELECT kostikConsistentHash(-1, 40000); -- { serverError 36 }
