-- Tags: no-fasttest
-- Tag no-fasttest: In fasttest, ENABLE_LIBRARIES=0, so rocksdb engine is not enabled by default
show create table system.rocksdb;
