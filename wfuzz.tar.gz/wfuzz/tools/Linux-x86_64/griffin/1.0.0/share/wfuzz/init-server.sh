#!/bin/bash -x
# Initialization script
# Used as ResetScriptLevel2

source ${WFUZZ_DB_ENV}

# kill the remaining server
${WFUZZ_DB_KILL_CMD}

# remove the data directory
rm -rf ${DATADIR}

echo "[wfuzz] initializing server"
${WFUZZ_DB_INIT_CMD}

echo "[wfuzz] starting server"
bash -xe ${WFUZZ_DB_START_CMD}
