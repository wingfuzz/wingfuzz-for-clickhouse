#!/bin/bash -x

source ${WFUZZ_DB_ENV}

cd ${pwd}

TIME=`date +%Y%m%d%H%M%S`
echo "[wfuzz] start test"

# start database server and create necessary databases
# if [ "${WFUZZ_DB_NO_SERVER}" == "" ]; then
#     echo "[wfuzz] starting server"
#     bash -e ${WFUZZ_DB_START_CMD}

#     SERVER_PID=$(jobs -p)
#     echo "[wfuzz] server started at pid $SERVER_PID"
#     echo -n $SERVER_PID > ${WFUZZ_DB_SERVER_PID_FILE}
#     trap "kill $SERVER_PID" EXIT
# fi

# # kill remaining database server processes~
${WFUZZ_DB_KILL_CMD}

# create directory for SDK to check
log_dir_parent=${TEST_DIR}/project/anomaly
mkdir -m 777 -p ${log_dir_parent}
log_content_dir=${log_dir_parent}/content
log_report_dir=${log_dir_parent}/report
mkdir -m 777 -p $log_content_dir
mkdir -m 777 -p $log_report_dir

# start fuzzing, -t specifies the timeout in ms
${GRIFFIN_PATH}/bin/afl-fuzz \
		-i ${TEST_DIR}/project/in \
		-o ${TEST_DIR}/project/afl_output_file \
		-t $(( ${ResetTimeoutLevel1} + ${ResetTimeoutLevel2} )) \
		-- ${GRIFFIN_PATH}/bin/autodriver_odbc_v5_aflpp test
