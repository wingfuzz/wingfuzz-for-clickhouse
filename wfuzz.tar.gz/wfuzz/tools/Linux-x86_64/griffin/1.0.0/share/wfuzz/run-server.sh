#!/bin/bash -x
# Start server script
# Used as ResetScriptLevel1

source ${WFUZZ_DB_ENV}

if [ -z "$WFUZZ_LOG_KEEP_LINES" ]; then
  WFUZZ_LOG_KEEP_LINES=2000
fi

echo "[wfuzz] starting server"
${WFUZZ_DB_SERVER_START_CMD} 2>&1 | $GRIFFIN_PATH/bin/logrotator ${TEST_DIR}/server.log.1 ${TEST_DIR}/server.log.2 $WFUZZ_LOG_KEEP_LINES &

while ! (echo "SELECT 'GRIFFIN OK';" | bash -xe ${WFUZZ_DB_CLIENT} | grep 'GRIFFIN OK'); do
    echo "[wfuzz] waiting for server to start"
    sleep 1
done

echo "[wfuzz] server started"
echo "create database test;"  | bash -xe ${WFUZZ_DB_CLIENT}
echo "create database test2;" | bash -xe ${WFUZZ_DB_CLIENT} 
