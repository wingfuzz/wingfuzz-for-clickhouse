SELECT identity(1 AS a) AS b, a, b;
