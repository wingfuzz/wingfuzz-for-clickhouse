SELECT count() FROM test.hits WHERE CounterID < 10000;
SELECT count() FROM test.hits WHERE 10000 > CounterID;
