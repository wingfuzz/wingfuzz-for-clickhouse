SELECT hex('\a\b\f\n\r\t\v\\\'\"\?\xAA');
