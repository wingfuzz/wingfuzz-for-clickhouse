select intDivOrZero(0, 0) = 0;
select intDivOrZero(-128, -1) = 0;
select intDivOrZero(-127, -1) = 127;
select intDivOrZero(1, 1) = 1;
select intDivOrZero(4, 2) = 2;
