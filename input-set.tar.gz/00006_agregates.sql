SELECT sum(AdvEngineID), count(), avg(ResolutionWidth) FROM test.hits
