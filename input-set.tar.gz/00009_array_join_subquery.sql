SELECT x FROM (SELECT arrayJoin(['Hello', 'Goodbye']) AS x)
