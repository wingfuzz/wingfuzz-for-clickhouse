SELECT count() FROM test.hits
