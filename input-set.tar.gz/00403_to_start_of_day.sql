SELECT toStartOfDay(now()) = toDateTime(toDate(now()));
