select arrayExists(x -> position(x, 'a') > 0, ['a'])
