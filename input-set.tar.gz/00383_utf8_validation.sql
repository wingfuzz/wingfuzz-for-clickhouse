SET output_format_write_statistics = 0;
SELECT '\xED\x20\xA8' AS s FORMAT JSONCompact;
