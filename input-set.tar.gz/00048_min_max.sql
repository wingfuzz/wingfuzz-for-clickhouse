SELECT min(EventDate), max(EventDate) FROM test.hits
