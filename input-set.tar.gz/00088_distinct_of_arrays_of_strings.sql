SELECT DISTINCT arrayFilter(x -> notEmpty(x), arrayJoin([[''], ['is_registred'], ['registration_month','user_login','is_registred'], ['is_registred'], ['is_registred'], ['']]));
