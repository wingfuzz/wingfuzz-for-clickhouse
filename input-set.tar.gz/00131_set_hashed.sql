SELECT (1, '') IN ((1, ''));
