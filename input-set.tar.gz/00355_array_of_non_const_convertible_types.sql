SELECT [toUInt8(number), number] FROM system.numbers LIMIT 3;
