SELECT toString(toFixedString(toString(number), 3)) FROM system.numbers LIMIT 111
