SELECT sum(Sign) FROM test.visits
