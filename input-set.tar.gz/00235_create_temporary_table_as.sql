drop temporary table if exists one_0023;
create temporary table one_0023 as select 1;
select * from one_0023;
