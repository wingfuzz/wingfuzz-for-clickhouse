SELECT [1];
SELECT [1, 255];
SELECT [1, 256];
SELECT [-1, -2.5, 15, 699];
SELECT ['q', 'w', 'ert', 'y'];
