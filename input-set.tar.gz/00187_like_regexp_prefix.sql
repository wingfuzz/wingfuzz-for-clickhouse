SELECT materialize('prepre_f') LIKE '%pre_f%';
