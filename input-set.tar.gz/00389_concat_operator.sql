SELECT 'Hello' || ', ' || 'World';
