SELECT 'a\tb\nc\td' AS x FORMAT Vertical;
