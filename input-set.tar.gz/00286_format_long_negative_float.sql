-- Tags: long

select reinterpretAsFloat64(unhex('875635ffffffbfbe'))
