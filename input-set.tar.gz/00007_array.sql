SELECT ['Hello', 'Goodbye'];
SELECT ['Hello'], ['Goodbye'];
SELECT [];
