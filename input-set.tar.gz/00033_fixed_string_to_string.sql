SELECT toString(toFixedString('', 10))
