SELECT (dummy IN (1)) AS x GROUP BY x;
SELECT (1 IN (0,2)) AS x GROUP BY x;
