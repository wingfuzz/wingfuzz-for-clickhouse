SELECT visibleWidth((1, 2)), visibleWidth([1, 2, 3]), visibleWidth((1, [2]));
